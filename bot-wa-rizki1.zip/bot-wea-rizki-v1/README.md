### I'm DimS Gift Me Stars 🌟 

## Tools

```bash
> Termux
> WhatsApp
> 2 HandPhone
```

## Install
Follow The Steps Below!

```bash
> termux-setup-storage
(after that tap on permission)
> pkg update -y
> pkg upgrade -y
> pkg install git -y
> git clone https://github.com/4NK3R-PRODUCT1ON/bot-wea-v2
> cd bot-wea-v2
> npm cache clear
> bash install.sh
> npm audit fix
> npm start / node index.js
```



## Features

| NEW USER | YES
| :---------------------------------------------: | :-----------: |
|  Daftar|✅|

|  CREATOR  |                                           YES |
| :---------------------------------------------: | :-----------: |
| Sticker Maker|✅|
| Sticker Gif Maker|✅|
| Convert Sticker To Image|✅|
| Convert Video To MP3|✅|
| Black Pink Logo Maker|✅|
| 3D Text Maker|✅|
| Glitch|✅|
| Quote Maker|✅|
| Water Maker|✅|
| Fire Text Maker
| Marvel Logo Maker|✅|
| Snow Write Maker|✅|
| Ninja Logo Maker|✅|
| Logo Wolf Maker|✅|
| And much more |✅|

| MEDIA | YES |
| :-----------------: | :-------: |
| Trend Twit|✅|
| YT Search|✅|
| Wattpad Search|✅|

| EDUCATION | YES |
| :-----------------: | :-------: |
| The Meaning Of The Name|✅|
| Text To Sticker|✅|
| Nulis Name/class/text|✅|
| Quotes|✅|

| DOWNLOADER | YES |
| :-----------------: | :-------: |
| Pinterest Downloader|✅|

| MEME | YES |
| :-----------------: | :-------: |
| Meme|✅|
| Meme Indo|✅|

| GROUP | YES |
| :-----------------: | :-------: |
| Anti link|✅|
| Open Group|✅|
| Link Group|✅|
| info Group|✅|
| Close Group|✅|
| Promote Member|✅|
| Demote Member|✅|
| Hide Tag|✅|
| Tag All Members|✅|
| Add Member|✅|
| Kick Member|✅|
| Show List Admins|✅|
| Leave Group|✅|
| Show Owner Group|✅|
| welcome New Members|✅|
| Nsfw|✅|

| SOUND | YES |
| :-----------------: | :-------: |
| Text To Speach|✅|

| MUSIC | YES |
| :-----------------: | :-------: |
| Music Lyrics|✅|
| Chord Guitar|✅|

| ISLAM | YES |
| :-----------------: | :-------: |
| Qur'an|✅|
| Qur'an Surah 1,2,3 dll |✅|

| STALK | YES |
| :-----------------: | :-------: |
| Instagram Stalk|✅|
| Tiktok Stalk|✅|

| WIBU | YES |
| :-----------------: | :-------: |
| Neonime|✅|
| Pokemon|✅|
| Nekonime|✅|
| Shota|✅|
| Kaneki|✅|
| Touka chan|✅|
| Naruto|✅|
| Loli|✅|
| Random Shota|✅|
| Random Waifu|✅|
| Random Anime|✅|
| And much more|✅|

| FUN | YES |
| :-----------------: | :-------: |
| Kucing|✅|
| Anjing|✅|
| Alay|✅|
| hilih|✅|
| Cek Ganteng|✅|
| Cantik cek|✅|
| Watak|✅|
| Quotes bucin|✅|
| Kata Cinta|✅|
| Random Hobby|✅|
| Search Image [optional]|✅|
| Pinterest [Optional] |✅|
| Truth Or Dare |✅|
| Dark Jokes|✅|
| Apakah|✅|
| Kapankah|✅|
| Bisakah|✅|
| Rate|✅|

| INFORMATION | YES |
| :-----------------: | :-------: |
| List Bahasa|✅|
| Information Weather|✅|
| KBBI|✅|
| Fakta|✅|
| Covid|✅|
| Gempa Terkini|✅|

| 18+ | YES |
| :-----------------: | :-------: |
| Random Hentai|✅|
| NSFW Neko|✅|
| NSFW Blowjob |✅|
| NSFW Loli|✅|
| NSFW Anime|✅|
| Asupan|✅|

| OWNER | YES |
| :-----------------: | :-------: |
| Add bucin|✅|
| Set pp bot|✅|
| Set Limit Harian|✅|
| Set Limit Member Group|✅|
| Set Reply Chat|✅|
| add premium |✅|
| Banned Member|✅|
| Unbanned Member|✅|
| Block Member|✅|
| Unblock Member|✅|
| remove premium |✅|
| Set Prefix|✅|
| Block Member|✅|
| Broadcast|✅|
| Group Broadcast|✅|
| Clear All Chat|✅|
| Bott aktif/nonaktif|✅|

| PREMIUM MENU | YES |
| :-----------------: | :-------: |
| Youtube mp3 Download|✅|
| Tiktok Downloader|✅|
| Youtube mp4 Download|✅|
| Joox|✅|
| Facebook Video Download|✅|
| Snack Video Download|✅|
| Play Mp3|✅|

 TENTANG BOT | YES |
| :-----------------: | :-------: |
| info|✅|
| Premium List|✅|
| User list|✅|
| Banned list|✅|
| Block list|✅|


## Note

* Dont Forget Stars

* |En| And You can add your own quotes
* |Ind| Dan Kalian Bisa tambahkan Quotes Kalian


## Special Thanks

* [Adiwajshing Baileys](https://github.com/adiwajshing/baileys)
* Created Bot => [MhankBarBar](https://github.com/MhankBarBar)
* [NURUTOMO](https://github.com/nurutomo)
* [NazwaS](https://github.com/nazwaS)
* [FXC7](https://github.com/Fxc7)
* [FXC7 OFFICIAL TEAM]


* [Req Fitur](https://wa.me/6281368646011)

## Group

* <a href="https://chat.whatsapp.com/BtxiSvctCej1e1Ehkm8h9Q"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

---
